package application;

import view.vwPessoaFisica;

public class Program {

	public static void main(String[] args) {

		vwPessoaFisica.gerarPessoaFisica();

	}
}
