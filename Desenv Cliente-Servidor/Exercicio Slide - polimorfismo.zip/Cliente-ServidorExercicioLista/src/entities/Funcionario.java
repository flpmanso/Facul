package entities;

public class Funcionario implements Pessoa {
	
	public double salario;

	public double calcularSalario(double salario) {
		return this.salario = salario;
			
	}
}
