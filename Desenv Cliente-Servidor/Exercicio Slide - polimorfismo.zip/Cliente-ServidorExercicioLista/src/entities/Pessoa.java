package entities;

public interface Pessoa {
	
	public double calcularSalario(double salario);
		
}