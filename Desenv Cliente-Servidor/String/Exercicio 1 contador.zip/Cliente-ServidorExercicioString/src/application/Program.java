package application;


public class Program {

	public static void main(String[] args) {
		
		
				
		String string = "teste de tamanho";
		
		System.out.println("String: " + string + ", contem " + string.length() + " caracteres");
		
	}

}
