package entities;

public class Supervisor {
	public static double salario;

	public static double calcSalario() {
		return salario + salario * 20 / 100;
	}

}
