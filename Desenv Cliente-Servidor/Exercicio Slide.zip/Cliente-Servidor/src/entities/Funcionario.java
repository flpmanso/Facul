package entities;

public class Funcionario {
	public static double salario;

	public static double calcSalario() {
		return salario;
			
	}
}
