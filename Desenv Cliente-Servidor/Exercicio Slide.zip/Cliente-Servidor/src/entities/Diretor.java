package entities;

public class Diretor {
	public static double salario;

	public static double calcSalario() {
		return salario + salario * 10 / 100;
	}
}
