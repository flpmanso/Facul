package application;

import entities.Pizzaria;

public class Program {

	public static void main(String[] args) {
		Pizzaria p = new Pizzaria();
		p.pedirPizza("calabresa");
		p.pedirPizza("napolitana");
		p.pedirPizza("portuguesa");
	}
}
