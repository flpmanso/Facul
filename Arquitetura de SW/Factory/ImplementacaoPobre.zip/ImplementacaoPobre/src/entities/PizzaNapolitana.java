package entities;

public class PizzaNapolitana extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana...");
    }
}
