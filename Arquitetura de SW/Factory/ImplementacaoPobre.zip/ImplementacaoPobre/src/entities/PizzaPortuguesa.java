package entities;

public class PizzaPortuguesa extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza portuguesa...");
    }
}
