package entities;

public class PizzaCalabresa extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa...");
    }
}