package application;

import entities.Pizzaria;
import entities.PizzariaGoiania;
import entities.PizzariaRio;
import entities.PizzariaSaoPaulo;

public class Program {

	public static void main(String[] args) {
		Pizzaria p = new PizzariaSaoPaulo();
		p.pedirPizza("napolitana");
		p.pedirPizza("calabresa");
		p = new PizzariaRio();
		p.pedirPizza("napolitana");
		p.pedirPizza("calabresa");
		p = new PizzariaGoiania();
		p.pedirPizza("napolitana");
		p.pedirPizza("calabresa");
		p.pedirPizza("portuguesa");
	}
}
