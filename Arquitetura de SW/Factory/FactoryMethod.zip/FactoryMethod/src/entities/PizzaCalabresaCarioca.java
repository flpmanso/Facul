package entities;

public class PizzaCalabresaCarioca extends Pizza {
	    public void preparar()  {
	        System.out.println("Preparando uma pizza calabresa � moda carioca...");
	    }
	}

