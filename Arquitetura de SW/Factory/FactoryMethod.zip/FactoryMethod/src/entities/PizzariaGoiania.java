package entities;

public class PizzariaGoiania extends Pizzaria {

	public Pizza getPizza(String tipo) {
		if (tipo == "napolitana")
			return new PizzaNapolitanaGoiania();
		else if (tipo == "calabresa")
			return new PizzaCalabresaGoiania();
		else if (tipo == "portuguesa")
			return new PizzaPortuguesaGoiania();
		return null;
	}
}
