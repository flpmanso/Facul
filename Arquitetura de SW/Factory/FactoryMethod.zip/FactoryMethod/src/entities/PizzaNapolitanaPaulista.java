package entities;

public class PizzaNapolitanaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana � moda paulista...");
    }
}

