package entities;

public class PizzaPortuguesaGoiania extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza portuguesa Goiana...");
    }
}
