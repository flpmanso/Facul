package entities;

public interface IFabrica {
	public Pizza getPizza(String tipo);
}
