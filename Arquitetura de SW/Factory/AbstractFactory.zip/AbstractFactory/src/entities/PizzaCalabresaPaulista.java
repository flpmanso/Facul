package entities;

public class PizzaCalabresaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa Paulista...");
    }
}