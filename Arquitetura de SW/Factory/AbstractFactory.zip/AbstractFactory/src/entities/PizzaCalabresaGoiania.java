package entities;

public class PizzaCalabresaGoiania extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa Goiana...");
    }
}