package services;

import entities.Pizza;
import entities.PizzaCalabresa;
import entities.PizzaNapolitana;
import entities.PizzaPortuguesa;

public class Fabrica {
	public static Pizza getPizza(String tipo) {
		if (tipo == "napolitana") {
			return new PizzaNapolitana();
		} else if (tipo == "calabresa") {
			return new PizzaCalabresa();
		}else if (tipo == "Portuguesa") {
			return new PizzaPortuguesa();
		}
		return null;
	}
}