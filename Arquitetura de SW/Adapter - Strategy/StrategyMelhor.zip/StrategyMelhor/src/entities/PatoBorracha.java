package entities;
import services.CG2;
import services.CV2;

public class PatoBorracha extends Pato    {
    public PatoBorracha() {
        cg = new CG2();
        cv = new CV2();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato de borracha...");
    }
}