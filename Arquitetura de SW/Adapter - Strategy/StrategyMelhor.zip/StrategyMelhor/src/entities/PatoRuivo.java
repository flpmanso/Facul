package entities;
import services.CG1;
import services.CV1;

public class PatoRuivo extends Pato    {
    public PatoRuivo() {
        cg = new CG1();
        cv = new CV1();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato ruivo...");
    }
}
