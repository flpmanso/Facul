package services;

public class CV2 implements ComportamentoVoar  {
    public void voar() {
        System.out.println("n�o posso voar...");
    }
}
