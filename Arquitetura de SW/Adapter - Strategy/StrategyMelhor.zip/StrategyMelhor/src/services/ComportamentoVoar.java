package services;
public interface ComportamentoVoar {
    public void voar();
}
