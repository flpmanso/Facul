package entities;
public interface IDado {
    int lerFace();
    void jogaDado();
}
