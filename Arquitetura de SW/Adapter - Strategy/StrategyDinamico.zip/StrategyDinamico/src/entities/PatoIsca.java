package entities;
import services.CG3;
import services.CV2;

public class PatoIsca extends Pato    {
    public PatoIsca() {
        cg = new CG3();
        cv = new CV2();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato isca...");
    }
}
