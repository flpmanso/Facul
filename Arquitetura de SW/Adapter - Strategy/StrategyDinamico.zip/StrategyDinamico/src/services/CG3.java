package services;
public class CG3 implements ComportamentoGrasnar  {
    public void grasnar() {
        System.out.println("silencio...");
    }
}