package services;
public interface ComportamentoGrasnar {
    public void grasnar();
}
