package services;
public class CV3 implements ComportamentoVoar  {
    public void voar() {
        System.out.println("pato voando a jato...");
    }
}
