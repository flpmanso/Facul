package services;
public class CV1 implements ComportamentoVoar  {
    public void voar() {
        System.out.println("pato voando...");
    }
}