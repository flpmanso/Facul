package entities;
public class PatoRuivo extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato ruivo...");
    }
}
