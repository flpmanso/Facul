package entities;
public class PatoIsca extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato isca...");
    }

    public void grasnar() {}

    public void voar() {}
}