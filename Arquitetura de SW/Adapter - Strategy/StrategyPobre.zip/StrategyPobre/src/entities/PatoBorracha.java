package entities;
public class PatoBorracha extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato de borracha...");
    }

    public void grasnar() {
        System.out.println("pato de borracha apitando...");
    }

    public void voar() {}
}
