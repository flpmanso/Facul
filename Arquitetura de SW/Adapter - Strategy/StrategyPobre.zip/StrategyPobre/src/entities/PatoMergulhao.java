package entities;
public class PatoMergulhao extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato mergulh�o...");
    }
}
