package Controller;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import entities.Pessoa;

public class DptoVendas {
    private List funcionarios = new ArrayList();

    public void addFuncionario(Pessoa func) {
        funcionarios.add(func);
    }

    public Iterator getIterator() {
//      return new IteratorLista(funcionarios);
        return funcionarios.iterator();
    }
}
