
public class Cliente {
	String nome;
	String sobreNome;
	String cpf;
	
	Cliente (String nome, String sobreNome, String cpf){
		this.nome = nome;
		this.sobreNome = sobreNome;
		this.cpf = cpf;
	}
}
