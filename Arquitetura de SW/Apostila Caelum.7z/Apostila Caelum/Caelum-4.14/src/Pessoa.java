
public class Pessoa {
	public String nome;
	public int idade;
	
	public void fazAniversario() {
		idade = idade +1;
	}

}
