package entities;

public class ManipuladordDeSeguroDeVida {
	private SeguroDeVida seguroDeVida;

}
