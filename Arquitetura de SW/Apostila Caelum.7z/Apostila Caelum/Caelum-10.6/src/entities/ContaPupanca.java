package entities;

public class ContaPupanca extends Conta {

}
