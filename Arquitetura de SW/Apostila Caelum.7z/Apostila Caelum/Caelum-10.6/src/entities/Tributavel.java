package entities;

public interface Tributavel {
	
	public double getValorImposto();

	public String getTitular();

	public String getTipo();
}
