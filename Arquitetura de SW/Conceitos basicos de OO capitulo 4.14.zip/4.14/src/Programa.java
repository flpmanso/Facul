
public class Programa {
	public static void main(String[] args) {
		Porta p = new Porta();
		
		p.aberta = "s";
		p.cor = "preta";
		p.pinta("azul");
				
		p.mostra();
	}
}
