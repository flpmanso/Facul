package entities;

public interface Bonificacao {
	
	public double calcularSalario(double salario);
		
}