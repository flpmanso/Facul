
import javax.persistence.Entity; 
import javax.persistence.GeneratedValue; 
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="empresa",name="cliente")
public class Cliente {
	String nome;
	String sobrenome;
	@Id
	String cpf;
	
	public Cliente(){}
	
	public Cliente(String nome, String sobrenome, String cpf){
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
	}
	
	public String toString(){
		return "Cliente "+nome+" ; "+sobrenome+" ; "+cpf;
	}
}
