import java.util.List;
import org.hibernate.SessionFactory; 
import org.hibernate.Transaction; 
import org.hibernate.cfg.AnnotationConfiguration; 
import org.hibernate.classic.Session;
public class HelloWorldHibernate {
    public static void main(String[] args) { 
              
        //Produto prod1 = new Produto();
        
    	//prod1.setNome("Sabonete");
    	//prod1.setId(2);
        
    	//listar(Produto.class);
    	
        //inserir(prod1);
    	//atualizar(prod1);
       
        //listar(Produto.class);
    	
    	Cliente c = new Cliente("Alexandre","Almeida","12345678910");
    	
    	inserir(c);
    	listar(Cliente.class);
        
    }
    
    private static void inserir (Object obj){
    	AnnotationConfiguration config = new AnnotationConfiguration();
    	
       config.addAnnotatedClass(obj.getClass());
        
        SessionFactory sessionFactory = config.buildSessionFactory(); 
        Session session = sessionFactory.openSession(); 
        
        Transaction tx = session.beginTransaction(); 
        session.persist(obj); 
        tx.commit();
    }
    
    private static void remover (Object obj){
    	AnnotationConfiguration config = new AnnotationConfiguration();
    	
       config.addAnnotatedClass(obj.getClass());
        
        SessionFactory sessionFactory = config.buildSessionFactory(); 
        Session session = sessionFactory.openSession(); 
        
        Transaction tx = session.beginTransaction(); 
        session.delete(obj); 
        tx.commit();
    }
    
    private static void atualizar (Object obj){
    	AnnotationConfiguration config = new AnnotationConfiguration();
    	
       config.addAnnotatedClass(obj.getClass());
        
        SessionFactory sessionFactory = config.buildSessionFactory(); 
        Session session = sessionFactory.openSession(); 
        
        Transaction tx = session.beginTransaction(); 
        session.merge(obj); 
        tx.commit();
    }
    
    private static void listar(Class cls){
    	AnnotationConfiguration config = new AnnotationConfiguration();
    	 config.addAnnotatedClass(cls); 
    	SessionFactory sessionFactory = config.buildSessionFactory(); 
        Session session = sessionFactory.openSession();
        
        List lista = session.createQuery("from "+cls.getName()).list();
        for (Object o: lista) { 
            System.out.println(o); 
        } 
        
        session.flush();
        session.close(); 
        sessionFactory.close();
    }
        
}
