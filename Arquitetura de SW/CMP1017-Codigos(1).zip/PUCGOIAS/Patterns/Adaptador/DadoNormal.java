package Patterns.Adaptador;

interface IDado {
    int lerFace();
    void jogaDado();
}

public class DadoNormal implements IDado {
    int lado;

    public void jogaDado() {
        lado = (int) (Math.random() * 6 + 1);
    }

    public int lerFace() {
        return lado;
    }
}

class DadoViciado  {
    public int jogaDado() {
        int face = (int) (Math.random() * 20 + 1);
        return (face > 5) ? 6 : face;
    }
}

class AdaptadorDadoViciado implements IDado  {
    private DadoViciado dado = new DadoViciado();

    private int face = 1;

    public int lerFace() {
        return face;
    }

    public void jogaDado() {
        face = dado.jogaDado();
    }
}

class Teste {
    public static void main(String args[]) {
        IDado dadoNormal = new DadoNormal();
        IDado dadoViciado = new AdaptadorDadoViciado();

        for (int i=1; i<10; i++)    {
            dadoNormal.jogaDado();
            System.out.println(dadoNormal.lerFace());
        }

        System.out.println();

        for (int i=1; i<10; i++)    {
            dadoViciado.jogaDado();
            System.out.println(dadoViciado.lerFace());
        }
    }
}
