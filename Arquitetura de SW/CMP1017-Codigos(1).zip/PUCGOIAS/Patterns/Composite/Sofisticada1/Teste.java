package Patterns.Composite.Sofisticada1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

class IteratorNulo implements Iterator {
    public void remove() {}

    public boolean hasNext() {
        return false;
    }

    public Object next() {
        return null;
    }
}

class IteratorComposto implements Iterator  {
    private Stack pilhaIterators = new Stack();
    Iterator iterator;

    public void remove() {}

    public boolean hasNext() {
        if (iterator.hasNext()) return true;
        if (pilhaIterators.size()>0)
            iterator = (Iterator)pilhaIterators.pop();
        else
            iterator = new IteratorNulo();
        return iterator.hasNext();
    }

    public Object next() {
    // a serious code
        if (hasNext())  {
            ComponenteArvore comp = (ComponenteArvore)iterator.next();
            if(comp instanceof Pessoa)
                return comp;
            else    {
                pilhaIterators.push(comp.getIterator());
                return next();
            }
        }
        else
            return null;
    }

    public IteratorComposto(Iterator umIterator)    {
        this.iterator = umIterator;
    }
}

abstract class ComponenteArvore {
    public abstract void print();

    public String getNome() {
        throw new UnsupportedOperationException();
    }

    public abstract Iterator getIterator();
}

class Pessoa extends ComponenteArvore {
    private String nome;
    private double salario;

    public Pessoa(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }

    public void print() {
        System.out.println(nome + "; " + salario);
    }

    public Iterator getIterator() {
        return new IteratorNulo();
    }
}

class Departamento extends ComponenteArvore {
    private List membros = new ArrayList();

    public void add(ComponenteArvore membro) {
        membros.add(membro);
    }

    public void print() {
        Iterator it = membros.iterator();
        while (it.hasNext()) {
            ComponenteArvore comp = (ComponenteArvore) it.next();
            comp.print();
        }
    }

    public Iterator getIterator() {
        return new IteratorComposto(membros.iterator());
    }
}


public class Teste {
    ComponenteArvore componente;

    public Teste(ComponenteArvore componente) {
        this.componente = componente;
    }

    public void printFuncionarios() {
        Iterator it = componente.getIterator();
        while (it.hasNext()) {
            ComponenteArvore pessoa = (ComponenteArvore) it.next();
            if (pessoa.getNome().length() > 5)
                pessoa.print();
        }
    }

    public static void main(String[] args) {
        Departamento dptoA = new Departamento();
        dptoA.add(new Pessoa("Alberto", 1000));
        dptoA.add(new Pessoa("Antonio", 1000));

        Departamento dptoB = new Departamento();
        dptoB.add(new Pessoa("Brito", 2000));
        dptoB.add(new Pessoa("Batista", 2000));
        Departamento dptoB1 = new Departamento();
        dptoB1.add(new Pessoa("Bento", 2000));
        dptoB1.add(new Pessoa("Bezerra", 2000));
        dptoB.add(dptoB1);

        Departamento dptoC = new Departamento();
        dptoC.add(new Pessoa("Carlos", 3000));
        dptoC.add(new Pessoa("Cardoso", 3000));

        Departamento empresa = new Departamento();
        empresa.add(dptoA);
        empresa.add(dptoB);
        empresa.add(dptoC);

        new Teste(empresa).printFuncionarios();
    }
}

