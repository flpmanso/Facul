package Patterns.Composite.Sofisticada2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

abstract class ElementoArvore  {
    public abstract void print();

    public abstract void getFolhas(List lista);

    public String getNome() {
        throw new UnsupportedOperationException();
    }
}

class Pessoa extends ElementoArvore   {
    private String nome;
    private double salario;

    public Pessoa(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }

    public void print()  {
        System.out.println(nome + "; " + salario);
    }

    public void getFolhas(List lista)   {
        lista.add(this);
    }
}

class Departamento extends ElementoArvore   {
    private List membros = new ArrayList();

    public void add(ElementoArvore elemento) {
        membros.add(elemento);
    }

    public void print() {
        Iterator it = membros.iterator();
        while(it.hasNext()) {
            ElementoArvore elemento = (ElementoArvore)it.next();
            elemento.print();
        }
    }

    public void getFolhas(List lista)   {
        Iterator it = membros.iterator();
        while(it.hasNext()) {
            ElementoArvore elemento = (ElementoArvore)it.next();
            elemento.getFolhas(lista);
        }
    }
}


public class Teste {
    public static Departamento empresa = new Departamento();

    static {    // inicializa��o
        Departamento dptoA = new Departamento();
        dptoA.add(new Pessoa("Alberto", 1000));
        dptoA.add(new Pessoa("Antonio", 1000));

        Departamento dptoB = new Departamento();
        dptoB.add(new Pessoa("Brito", 2000));
        dptoB.add(new Pessoa("Batista", 2000));
        Departamento dptoB1 = new Departamento();
        dptoB1.add(new Pessoa("Bento", 2000));
        dptoB1.add(new Pessoa("Bezerra", 2000));
        dptoB.add(dptoB1);

        Departamento dptoC = new Departamento();
        dptoC.add(new Pessoa("Carlos", 3000));
        dptoC.add(new Pessoa("Cardoso", 3000));

        empresa.add(dptoA);
        empresa.add(dptoB);
        empresa.add(dptoC);
    }

    public static void main(String[] args) {
        List lista = new ArrayList();
        empresa.getFolhas(lista);
        Iterator it = lista.iterator();
        while(it.hasNext()) {
            ElementoArvore elemento = (ElementoArvore)it.next();
            if(elemento.getNome().toUpperCase().charAt(0)=='B')
                System.out.println(elemento.getNome());

        }
    }
}

