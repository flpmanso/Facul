package Patterns.Iterator.ImplementacaoPobre;

import java.util.ArrayList;
import java.util.List;

class Pessoa {
    private String nome;
    private double salario;

    public Pessoa(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }
}

class DptoVendas {
    private static List funcionarios = new ArrayList();

    public void addFuncionario(Pessoa func) {
        funcionarios.add(func);
    }

    public List getColecao() {
        return funcionarios;
    }
}

class DptoMarketing {
    private int pos = 0;
    private final int DIM = 10;
    private Pessoa funcionarios[] = new Pessoa[DIM];

    public void addFuncionario(Pessoa func) {
        if (pos >= DIM) return;
        funcionarios[pos] = func;
        pos++;
    }

    public Pessoa[] getColecao() {
        return funcionarios;
    }
}

public class Teste {
    private static DptoMarketing dMarketing = new DptoMarketing();
    private static DptoVendas dVendas = new DptoVendas();

    static {   // inicializa��o
        dMarketing.addFuncionario(new Pessoa("Manoel", 4000));
        dMarketing.addFuncionario(new Pessoa("Mauro", 4000));
        dVendas.addFuncionario(new Pessoa("Vinicius", 2000));
        dVendas.addFuncionario(new Pessoa("Vitor", 2000));
    }

    public static void main(String[] args) {
        List lista = dVendas.getColecao();
        for (int i = 0; i < lista.size(); i++) {
            Pessoa pessoa = (Pessoa) lista.get(i);
            System.out.println(pessoa.getNome() + "; " + pessoa.getSalario());
        }

        Pessoa array[] = dMarketing.getColecao();
        for (int i = 0; i < array.length; i++) {
            Pessoa pessoa = array[i];
            if(pessoa==null) break;
            System.out.println(pessoa.getNome() + "; " + pessoa.getSalario());
        }
    }
}

