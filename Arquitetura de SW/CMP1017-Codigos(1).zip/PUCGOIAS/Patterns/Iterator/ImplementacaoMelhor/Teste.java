package Patterns.Iterator.ImplementacaoMelhor;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;

/*
interface Iterator  {
    public boolean hasNext();
    public Object next();
}

class IteratorLista implements Iterator {
    private int pos=0;
    private List lista;

    public IteratorLista(List lista)    {
        this.lista = lista;
    }

    public boolean hasNext()    {
        return pos<lista.size()?true:false;
    }

    public Object next()    {
        if (!hasNext()) return null;
        return lista.get(pos++);
    }
}

*/
class IteratorArray implements Iterator {
    private int pos=0;
    private Object array[];

    public IteratorArray(Object array[])    {
        this.array = array;
    }

    public boolean hasNext()    {
        return pos<array.length&&array[pos]!=null?true:false;
    }

    public Object next()    {
        if (!hasNext()) return null;
        return array[pos++];
    }

    public void remove(){}
}

class Pessoa {
    private String nome;
    private double salario;

    public Pessoa(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }
}

class DptoVendas {
    private List funcionarios = new ArrayList();

    public void addFuncionario(Pessoa func) {
        funcionarios.add(func);
    }

    public Iterator getIterator() {
//      return new IteratorLista(funcionarios);
        return funcionarios.iterator();
    }
}

class DptoMarketing {
    private int pos = 0;
    private final int DIM = 10;
    private Pessoa funcionarios[] = new Pessoa[DIM];

    public void addFuncionario(Pessoa func) {
        if (pos >= DIM) return;
        funcionarios[pos] = func;
        pos++;
    }

    public Iterator getIterator() {
        return new IteratorArray(funcionarios);
    }
}

class DptoCompras {
    private HashMap funcionarios = new HashMap();

    public void addFuncionario(Pessoa func) {
        funcionarios.put(func.getNome(), func);
    }

    public Iterator getIterator() {
        return funcionarios.values().iterator();
    }
}

public class Teste {
    private static DptoMarketing dMarketing = new DptoMarketing();
    private static DptoVendas dVendas = new DptoVendas();
    private static DptoCompras dCompras = new DptoCompras();

    static {   // inicializa��o
        dMarketing.addFuncionario(new Pessoa("Manoel", 4000));
        dMarketing.addFuncionario(new Pessoa("Mauro", 4000));
        dVendas.addFuncionario(new Pessoa("Vinicius", 3000));
        dVendas.addFuncionario(new Pessoa("Vitor", 3000));
        dCompras.addFuncionario(new Pessoa("Cardoso", 2000));
        dCompras.addFuncionario(new Pessoa("Celso", 2000));
    }

    public static void main(String[] args) {
        Iterator it = dVendas.getIterator();
        while(it.hasNext()) {
            Pessoa pessoa = (Pessoa) it.next();
            System.out.println(pessoa.getNome() + "; " + pessoa.getSalario());
        }

        it = dMarketing.getIterator();
        while(it.hasNext()) {
            Pessoa pessoa = (Pessoa) it.next();
            System.out.println(pessoa.getNome() + "; " + pessoa.getSalario());
        }

        it = dCompras.getIterator();
        while(it.hasNext()) {
            Pessoa pessoa = (Pessoa) it.next();
            System.out.println(pessoa.getNome() + "; " + pessoa.getSalario());
        }
    }
}

