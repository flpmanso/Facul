package Patterns.Factory.AbstractFactory;

class Pizzaria  {
    private IFabrica fabrica;

    public Pizzaria(IFabrica fabrica)   {
        this.fabrica = fabrica;
    }

    public void setFabrica(IFabrica fabrica) {
        this.fabrica = fabrica;
    }

    public Pizza pedirPizza(String tipo)    {
        Pizza pizza = fabrica.getPizza(tipo);

        pizza.preparar();
        pizza.assar();
        pizza.cortar();
        pizza.embalar();
        System.out.println();
        return pizza;
    }
}

interface IFabrica  {
    public Pizza getPizza(String tipo);
}

class FabricaSP implements IFabrica {
    public Pizza getPizza(String tipo)  {
        if(tipo=="napolitana")
            return new PizzaNapolitanaPaulista();
        else if(tipo=="calabresa")
            return new PizzaCalabresaPaulista();
        return null;
    }
}

class FabricaRJ implements IFabrica {
    public Pizza getPizza(String tipo)  {
        if(tipo=="napolitana")
            return new PizzaNapolitanaCarioca();
        else if(tipo=="calabresa")
            return new PizzaCalabresaCarioca();
        return null;
    }
}

abstract class Pizza    {
    public abstract void preparar();

    public void assar() {
        System.out.println("assar a 300 graus...");
    }

    public void cortar()    {
        System.out.println("cortando na diagonal...");
    }

    public void embalar()   {
        System.out.println("embalando para viagem...");
    }
}

class PizzaNapolitanaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana � moda paulista...");
    }
}

class PizzaCalabresaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa � moda paulista...");
    }
}

class PizzaNapolitanaCarioca extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana � moda carioca...");
    }
}

class PizzaCalabresaCarioca extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa � moda carioca...");
    }
}

class TestaPizzaria {
    public static void main(String[] args) {
        Pizzaria p = new Pizzaria(new FabricaRJ());
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
        p.setFabrica(new FabricaSP());
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
    }
}

