package Patterns.Factory.SimpleFactory;

class Pizzaria  {
    public Pizza pedirPizza(String tipo)    {
        Pizza pizza = Fabrica.getPizza(tipo);
        pizza.preparar();
        pizza.assar();
        pizza.cortar();
        pizza.embalar();
        System.out.println();
        return pizza;
    }
}

abstract class Pizza    {
    public abstract void preparar();

    public void assar() {
        System.out.println("assar a 300 graus...");
    }

    public void cortar()    {
        System.out.println("cortando na diagonal...");
    }

    public void embalar()   {
        System.out.println("embalando para viagem...");
    }
}

class PizzaNapolitana extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana...");
    }
}

class PizzaCalabresa extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa...");
    }
}

class Fabrica   {
    public static Pizza getPizza(String tipo)  {
        if(tipo=="napolitana")  {
            return new PizzaNapolitana();
        }
        else if(tipo=="calabresa")  {
            return new PizzaCalabresa();
        }
        return null;
    }
}

class TestaPizzaria {
    public static void main(String[] args) {
        Pizzaria p = new Pizzaria();
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
    }
}

