package Patterns.Factory.ImplementacaoPobre;

class Pizzaria  {
    private Pizza pizza = null;
    
    public Pizza pedirPizza(String tipo)    {

        if(tipo=="napolitana")  {
            pizza = new PizzaNapolitana();
        }
        else if(tipo=="calabresa")  {
            pizza = new PizzaCalabresa();
        }

        pizza.preparar();
        pizza.assar();
        pizza.cortar();
        pizza.embalar();
        System.out.println();
        return pizza;
    }
}

abstract class Pizza    {
    public abstract void preparar();

    public void assar() {
        System.out.println("assar a 300 graus...");
    }

    public void cortar()    {
        System.out.println("cortando na diagonal...");
    }

    public void embalar()   {
        System.out.println("embalando para viagem...");
    }
}

class PizzaNapolitana extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana...");
    }
}

class PizzaCalabresa extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa...");
    }
}

class TestaPizzaria {
    public static void main(String[] args) {
        Pizzaria p = new Pizzaria();
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
    }
}

