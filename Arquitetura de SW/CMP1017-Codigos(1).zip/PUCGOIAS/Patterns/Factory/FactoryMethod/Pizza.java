package Patterns.Factory.FactoryMethod;

import Patterns.Factory.ImplementacaoPobre.*;

abstract class Pizzaria  {
    public Pizza pedirPizza(String tipo)    {
        Pizza pizza = getPizza(tipo);

        pizza.preparar();
        pizza.assar();
        pizza.cortar();
        pizza.embalar();
        System.out.println();
        return pizza;
    }

    public abstract Pizza getPizza(String tipo);
}

class PizzariaSaoPaulo extends Pizzaria {
    public Pizza getPizza(String tipo) {
        if(tipo=="napolitana")
            return new PizzaNapolitanaPaulista();
        else if(tipo=="calabresa")
            return new PizzaCalabresaPaulista();
        return null;
    }
}

class PizzariaRio extends Pizzaria {
    public Pizza getPizza(String tipo) {
        if(tipo=="napolitana")
            return new PizzaNapolitanaCarioca();
        else if(tipo=="calabresa")
            return new PizzaCalabresaCarioca();
        return null;
    }
}

abstract class Pizza    {
    public abstract void preparar();

    public void assar() {
        System.out.println("assar a 300 graus...");
    }

    public void cortar()    {
        System.out.println("cortando na diagonal...");
    }

    public void embalar()   {
        System.out.println("embalando para viagem...");
    }
}

class PizzaNapolitanaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana � moda paulista...");
    }
}

class PizzaCalabresaPaulista extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa � moda paulista...");
    }
}

class PizzaNapolitanaCarioca extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana � moda carioca...");
    }
}

class PizzaCalabresaCarioca extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa � moda carioca...");
    }
}

class Cliente   {
    public static void main(String[] args) {
        Pizzaria p = new PizzariaSaoPaulo();
        p.pedirPizza("napolitana");
        p.pedirPizza("calabresa");
        p = new PizzariaRio();
        p.pedirPizza("napolitana");
        p.pedirPizza("calabresa");
    }
}