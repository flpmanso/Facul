package Patterns.Singleton;

class Pizzaria  {
    private IFabrica fabrica;

    public Pizzaria(IFabrica fabrica)    {
        this.fabrica = fabrica;
    }

    public void setFabrica(IFabrica fabrica) {
        this.fabrica = fabrica;
    }

    public Pizza pedirPizza(String tipo)    {
        Pizza pizza = fabrica.getPizza(tipo);

        pizza.preparar();
        pizza.assar();
        pizza.cortar();
        pizza.embalar();
        System.out.println();
        return pizza;
    }
}

interface IFabrica   {
    public Pizza getPizza(String tipo);
}

class FabricaRJ implements IFabrica  {
    private static FabricaRJ instancia = new FabricaRJ();

    private FabricaRJ()  {}

    public static FabricaRJ getInstancia()  {
        return instancia;
    }

    public Pizza getPizza(String tipo)  {
        if(tipo=="napolitana")  {
            return new PizzaNapolitanaRJ();
        }
        else if(tipo=="calabresa")  {
            return new PizzaCalabresaRJ();
        }
        else return null;
    }
}

class FabricaSP implements IFabrica  {
    private static FabricaSP instancia = new FabricaSP();

    private FabricaSP()  {}

    public static FabricaSP getInstancia()  {
        return instancia;
    }

    public Pizza getPizza(String tipo)  {
        if(tipo=="napolitana")  {
            return new PizzaNapolitanaSP();
        }
        else if(tipo=="calabresa")  {
            return new PizzaCalabresaSP();
        }
        else return null;
    }
}

abstract class Pizza    {
    public abstract void preparar();

    public void assar() {
        System.out.println("assar a 300 graus...");
    }

    public void cortar()    {
        System.out.println("cortando na diagonal...");
    }

    public void embalar()   {
        System.out.println("embalando para viagem...");
    }
}

class PizzaNapolitanaRJ extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana carioca...");
    }
}

class PizzaCalabresaRJ extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa carioca...");
    }
}

class PizzaNapolitanaSP extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza napolitana paulista...");
    }
}

class PizzaCalabresaSP extends Pizza {
    public void preparar()  {
        System.out.println("Preparando uma pizza calabresa paulista...");
    }
}


class TestaPizzaria {
    public static void main(String[] args) {
        Pizzaria p = new Pizzaria(FabricaRJ.getInstancia());
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
        p.setFabrica(FabricaSP.getInstancia());
        p.pedirPizza("calabresa");
        p.pedirPizza("napolitana");
    }
}

