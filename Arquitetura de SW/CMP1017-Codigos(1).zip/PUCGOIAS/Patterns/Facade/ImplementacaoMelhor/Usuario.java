package Patterns.Facade.ImplementacaoMelhor;

import java.util.*;

class Biblioteca    {
    private static List usuarios = new ArrayList();

    public static Iterator getUsuarios()    {
        return usuarios.iterator();
    }

    public static void addUsuario(Usuario usuario)  {
        usuarios.add(usuario);
    }
}

public class Usuario {
    private String nome;
    private List emprestimos = new ArrayList();

    public Usuario(String nome) {
        this.nome = nome;
    }

    public Iterator getEmprestimosAbertos() {
        List lista = new ArrayList();
        for(int i=0; i<emprestimos.size(); i++) {
            Emprestimo e = (Emprestimo)emprestimos.get(i);
            if(e.getDevolucao()==null)   {
                lista.add(e);
            }
        }
        return lista.iterator();
    }

    public void addEmprestimo(Emprestimo e) {
        emprestimos.add(e);
    }
}

class Emprestimo    {
    private Date dtEmprestimo;
    private Date dtDevolucao = null;
    private Livro livro;

    public Emprestimo(Date dtEmprestimo, Livro livro) {
        this.dtEmprestimo = dtEmprestimo;
        this.livro = livro;
    }

    public Date getDevolucao()  {
        return dtDevolucao;
    }

    public Livro getLivro()  {
        return livro;
    }

    public void encerra(Date dt)    {
        dtDevolucao = dt;
    }
}

class Livro {
    private String ISBN;
    private String titulo;
    private String autor;

    public Livro(String autor, String ISBN, String titulo) {
        this.autor = autor;
        this.ISBN = ISBN;
        this.titulo = titulo;
    }

    public String getTitulo()   {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getISBN() {
        return ISBN;
    }
}

class Fachada {
    public Iterator getTitulosEmprestados() {
        List titulosEmprestados = new ArrayList();

        Iterator usuarios = Biblioteca.getUsuarios();
        while(usuarios.hasNext())   {
            Usuario usuario = (Usuario)usuarios.next();
            Iterator emprestimos = usuario.getEmprestimosAbertos();
            while(emprestimos.hasNext()) {
                Emprestimo emprestimo = (Emprestimo)emprestimos.next();
                Livro livro = emprestimo.getLivro();
                titulosEmprestados.add(livro.getTitulo());
            }
        }
        
        return titulosEmprestados.iterator();
    }
}

class Cliente   {
    private Usuario u1, u2;
    private Emprestimo e1, e2, e3, e4;
    private Livro l1, l2, l3;

    public void init()  {
        Date hoje = new Date(new GregorianCalendar().getTimeInMillis());
        Date ontem = new Date(new GregorianCalendar(2005, 2, 9).getTimeInMillis()); // 9-Marco-2005
        u1 = new Usuario("Jonas Knopman");
        u2 = new Usuario("Eduardo Knopman");
        Biblioteca.addUsuario(u1);
        Biblioteca.addUsuario(u2);
        l1 = new Livro("Martin Fowler", "0321127420", "Patterns of Enterprise Application Architecture");
        l2 = new Livro("Deitel", "8576050196", "Java Como Programar");
        l3 = new Livro("Craig Larman", "0131489062", "Applying UML and Patterns");
        e1 = new Emprestimo(hoje, l1);
        u1.addEmprestimo(e1);
        e2 = new Emprestimo(ontem, l2);
        u1.addEmprestimo(e2);
        e2.encerra(hoje);
        e3 = new Emprestimo(hoje, l2);
        u2.addEmprestimo(e3);
        e4 = new Emprestimo(hoje, l3);
        u2.addEmprestimo(e4);
    }

    public Cliente()    {
        init();

        Fachada fachada = new Fachada();
        Iterator titulos = fachada.getTitulosEmprestados();
        while(titulos.hasNext())    {
            String titulo = (String)titulos.next();
            System.out.println(titulo);
        }
    }

    public static void main(String[] args) {
        new Cliente();
    }
}
