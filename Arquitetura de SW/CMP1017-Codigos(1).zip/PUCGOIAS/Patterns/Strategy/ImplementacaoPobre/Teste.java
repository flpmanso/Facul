package Patterns.Strategy.ImplementacaoPobre;

abstract class Pato {
    public void nadar() {
        System.out.println("pato nadando...");
    }

    public void grasnar() {
        System.out.println("pato grasnando...");
    }

    public void voar() {
        System.out.println("pato voando...");
    }

    public abstract void desenharPato();
}

class PatoMergulhao extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato mergulh�o...");
    }
}

class PatoRuivo extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato ruivo...");
    }
}

class PatoBorracha extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato de borracha...");
    }

    public void grasnar() {
        System.out.println("pato de borracha apitando...");
    }

    public void voar() {}
}

class PatoIsca extends Pato    {
    public void desenharPato() {
        System.out.println("desenhando um pato isca...");
    }

    public void grasnar() {}

    public void voar() {}
}

public class Teste  {
    public static void main(String[] args) {
        Pato p1 = new PatoMergulhao();
        Pato p2 = new PatoBorracha();
        p1.voar();
        p1.grasnar();
        p1.desenharPato();
        p2.voar();
        p2.grasnar();
        p2.desenharPato();
    }
}