package Patterns.Strategy.ImplementacaoMelhor;

abstract class Pato {
    public ComportamentoGrasnar cg;
    public ComportamentoVoar cv;

    public void nadar() {
        System.out.println("pato nadando...");
    }

    public void grasnar() {
        cg.grasnar();
    }

    public void voar()  {
        cv.voar();
    }

    public abstract void desenharPato();
}

// comportamentos voar
interface ComportamentoVoar {
    public void voar();
}

class CV1 implements ComportamentoVoar  {
    public void voar() {
        System.out.println("pato voando...");
    }
}

class CV2 implements ComportamentoVoar  {
    public void voar() {
        System.out.println("n�o posso voar...");
    }
}

// comportamentos grasnar
interface ComportamentoGrasnar {
    public void grasnar();
}

class CG1 implements ComportamentoGrasnar  {
    public void grasnar() {
        System.out.println("pato grasnando...");
    }
}

class CG2 implements ComportamentoGrasnar  {
    public void grasnar() {
        System.out.println("pato apitando...");
    }
}

class CG3 implements ComportamentoGrasnar  {
    public void grasnar() {
        System.out.println("silencio...");
    }
}

// os patos
class PatoMergulhao extends Pato    {
    public PatoMergulhao() {
        cg = new CG1();
        cv = new CV1();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato mergulh�o...");
    }
}

class PatoRuivo extends Pato    {
    public PatoRuivo() {
        cg = new CG1();
        cv = new CV1();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato ruivo...");
    }
}

class PatoBorracha extends Pato    {
    public PatoBorracha() {
        cg = new CG2();
        cv = new CV2();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato de borracha...");
    }
}

class PatoIsca extends Pato    {
    public PatoIsca() {
        cg = new CG3();
        cv = new CV2();
    }

    public void desenharPato() {
        System.out.println("desenhando um pato isca...");
    }
}

public class Teste  {
    public static void main(String[] args) {
        Pato p[] = {new PatoMergulhao(), new PatoRuivo(), new PatoBorracha(), new PatoIsca()};
        for(int i=0; i<p.length; i++)   {
            p[i].desenharPato();
            p[i].nadar();
            p[i].voar();
            p[i].grasnar();
            System.out.println();
        }
    }
}