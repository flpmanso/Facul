package isp_correto;

public class Servico {

	/**
	 * @param args
	 */
	
		
	public static void main(String[] args) {
		ScrumMaster sm = new ScrumMaster();
				
		sm.BlindarTime();		
		
	}

}
