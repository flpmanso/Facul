package isp_correto;

public class ScrumMaster implements FuncaoDeScrumMaster{

	public void BlindarTime() {
		System.out.println("Scrum Master diz: Desenvolvedores Trabalhando!!! N�o ultrapasse!!!!");
	}
}
