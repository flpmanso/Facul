package isp_correto;

public interface FuncaoDeProductOwner {
	void PriorizarBacklog();
}
