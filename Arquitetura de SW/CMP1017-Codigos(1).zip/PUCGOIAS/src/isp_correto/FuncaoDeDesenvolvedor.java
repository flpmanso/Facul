package isp_correto;

public interface FuncaoDeDesenvolvedor {
	void ImplementarFuncionalidades();
}
