package isp_correto;

public interface FuncaoDeScrumMaster {
	void BlindarTime();
}
