package isp_problema;

public class ScrumMaster implements MembroDeTimeScrum {

	public void PriorizarBacklog() {
		System.out.println("Scrum Master diz: Priorizar backulog? Isso n�o � a fun��o do Product Owner?");

	}

	public void BlindarTime() {
		System.out.println("Scrum Master diz: Desenvolvedores Trabalhando!!! N�o ultrapasse!!!!");
	}

	public void ImplementarFuncionalidades() {
		System.out.println("Scrum Master diz: Codificar? Isso n�o � papel dos desenvolvedores?");
	}

}
