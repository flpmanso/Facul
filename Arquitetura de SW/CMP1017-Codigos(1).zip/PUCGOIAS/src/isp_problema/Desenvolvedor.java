package isp_problema;

public class Desenvolvedor implements MembroDeTimeScrum {

	public void PriorizarBacklog() {
		System.out.println("Priorizar backulog? Isso n�o � a fun��o do Product Owner?");

	}
	
	public void BlindarTime() {
		System.out.println("Blindar time? Isso n�o � a fun��o do Scrum Master?");
	}

	public void ImplementarFuncionalidades() {
		System.out.println("Codificando e tomando caf� compulsivamente!!");
	}

}
