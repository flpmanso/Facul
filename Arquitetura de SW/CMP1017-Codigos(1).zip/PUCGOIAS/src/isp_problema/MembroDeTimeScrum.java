package isp_problema;

public interface MembroDeTimeScrum {
	void PriorizarBacklog();
    void BlindarTime();
    void ImplementarFuncionalidades();
}
