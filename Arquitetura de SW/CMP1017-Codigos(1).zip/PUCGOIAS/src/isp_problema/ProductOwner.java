package isp_problema;

public class ProductOwner implements MembroDeTimeScrum {

	public void PriorizarBacklog() {
		System.out.println("Priorizando backlog com base nas minhas necessidades de neg�cio");
	}

	public void BlindarTime() {
		System.out.println("Blindar time? Isso n�o � a fun��o do Scrum Master?");
	}

	public void ImplementarFuncionalidades() {
		System.out.println("Codificar? Isso n�o � papel dos desenvolvedores?");
	}

}
