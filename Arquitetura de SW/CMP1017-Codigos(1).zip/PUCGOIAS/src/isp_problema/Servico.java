package isp_problema;

public class Servico {

	/**
	 * @param args
	 */
	
		
	public static void main(String[] args) {
		ScrumMaster sm = new ScrumMaster();
		ProductOwner po = new ProductOwner();
		Desenvolvedor dev1 = new Desenvolvedor();
		Desenvolvedor dev2 = new Desenvolvedor();
		Desenvolvedor dev3 = new Desenvolvedor();
		
		sm.ImplementarFuncionalidades();
		sm.BlindarTime();
		sm.PriorizarBacklog();
	}

}
