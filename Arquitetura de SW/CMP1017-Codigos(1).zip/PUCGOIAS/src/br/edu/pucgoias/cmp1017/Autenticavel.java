package br.edu.pucgoias.cmp1017;

public interface Autenticavel {
	
	boolean autentica(String senha);
	boolean validaNome(String Nome);

}
