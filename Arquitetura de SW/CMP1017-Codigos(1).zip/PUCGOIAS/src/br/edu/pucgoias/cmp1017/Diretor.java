package br.edu.pucgoias.cmp1017;

public class Diretor extends Funcionario {
	
	Diretor(String nome, String cpf, double salario) {
		super(nome, cpf, salario);		
	}

	public double getBonificacao(){
		return salario * 0.2;
		
	}
}
