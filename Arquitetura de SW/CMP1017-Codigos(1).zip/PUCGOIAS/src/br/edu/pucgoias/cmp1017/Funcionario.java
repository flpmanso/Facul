package br.edu.pucgoias.cmp1017;

public class Funcionario {
	String nome;	
	String cpf;
	double salario;
	
	Funcionario (String nome, String cpf, double salario){
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
	}
	
	public double getBonificacao() {
	    return this.salario * 0.10;
	}
	
	public String getNome(){
		return this.nome;
	}	
}
