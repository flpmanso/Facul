package br.edu.pucgoias.cmp1017;

public class ControlaBonificacao {

	public static void registraBonificacao(Funcionario func){
		System.out.println("A bonifica��o para o funcion�rio "+func.getNome()+" � de R$"+func.getBonificacao()+"!");
	}
	
	public static void main(String[] args) {
		Funcionario func1 = new Funcionario("Alexandre","777.702.708-84",2000);
		Gerente gerente = new Gerente("Cl�udio","777.712.333-55",2000);
		Diretor dir = new Diretor("Jos�", "777.200.000-00", 10000);
		
		registraBonificacao(func1);
		registraBonificacao(gerente);
		registraBonificacao(dir);
	}

}
