package br.edu.pucgoias.cmp1017;

public class Gerente extends Funcionario implements Autenticavel {
	
	Gerente (String nome, String cpf, double salario){
		super(nome,cpf,salario);
	}
	
	public double getBonificacao() {
	    return super.salario * 0.15;
	}
	
	public boolean autentica(String senha){
		return true;
	}
	
	public boolean validaNome(String nome){
		return true;
	}
}
