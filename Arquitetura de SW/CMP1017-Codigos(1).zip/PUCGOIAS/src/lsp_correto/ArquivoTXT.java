package lsp_correto;

public class ArquivoTXT extends Arquivo {

	public ArquivoTXT(String nome) {
		super(nome);
		// TODO Auto-generated constructor stub
	}
	
	public void gerarArquivo(){
		System.out.println("O arquivo txt: "+super.nome+".txt foi gerado com sucesso!");
	}

}
