package lsp_correto;

import java.util.ArrayList;

public class GeradorDeArquivos {

	public static void GerarArquivos(ArrayList<Arquivo> arquivos)
    {
        for(int i = 0; i < arquivos.size() ; i++)
        {
            arquivos.get(i).gerarArquivo();
             
        }
    }
	
	public static void main(String[] args) {
		Arquivo arq1 = new ArquivoPDF("Arquivo1");
		Arquivo arq2 = new ArquivoWord("Arquivo1");
		Arquivo arq3 = new ArquivoTXT("Arquivo3");
		
		ArrayList<Arquivo> lista = new ArrayList<Arquivo>();
		
		lista.add(arq1);
		lista.add(arq2);
		lista.add(arq3);
		
		GerarArquivos(lista);
	}

}
