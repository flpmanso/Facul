package lsp_correto;

public abstract class Arquivo {
	public String nome;
	
	public Arquivo(String nome){
		this.nome = nome;
	}
	
	public void gerarArquivo(){
	
	}
}
