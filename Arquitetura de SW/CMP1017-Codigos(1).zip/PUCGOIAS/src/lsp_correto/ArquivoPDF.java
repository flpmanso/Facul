package lsp_correto;

public class ArquivoPDF extends Arquivo {
		
	public ArquivoPDF(String nome) {
		super(nome);		
	}

	public void gerarArquivo(){
		System.out.println("O arquivo pdf: "+super.nome+".pdf foi gerado com sucesso!");
	}
}
