package lsp_problema;

public class Arquivo {
	public String nome;
	
	public Arquivo(String nome){
		this.nome = nome;
	}
}
