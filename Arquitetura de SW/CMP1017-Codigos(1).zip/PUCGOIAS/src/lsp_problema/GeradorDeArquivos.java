package lsp_problema;

import java.util.ArrayList;

public class GeradorDeArquivos {

	public static void GerarArquivos(ArrayList<Arquivo> arquivos)
    {
        for(int i = 0; i < arquivos.size() ; i++)
        {
            if (arquivos.get(i) instanceof ArquivoWord)
                ((ArquivoWord)arquivos.get(i)).gerarArquivoWord();
            else if (arquivos.get(i) instanceof ArquivoPDF)
            	((ArquivoPDF)arquivos.get(i)).gerarArquivoPDF(); 
        }
    }
	
	public static void main(String[] args) {
		Arquivo arq1 = new ArquivoPDF("Arquivo1");
		Arquivo arq2 = new ArquivoWord("Arquivo1");
		
		ArrayList<Arquivo> lista = new ArrayList<Arquivo>();
		
		lista.add(arq1);
		lista.add(arq2);
		
		GerarArquivos(lista);
	}

}
