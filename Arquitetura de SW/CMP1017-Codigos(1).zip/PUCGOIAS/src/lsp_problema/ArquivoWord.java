package lsp_problema;

public class ArquivoWord extends Arquivo {

	public ArquivoWord(String nome) {
		super(nome);
		// TODO Auto-generated constructor stub
	}
	
	public void gerarArquivoWord(){
		System.out.println("O arquivo doc: "+super.nome+".doc foi gerado com sucesso!");
	}

}
