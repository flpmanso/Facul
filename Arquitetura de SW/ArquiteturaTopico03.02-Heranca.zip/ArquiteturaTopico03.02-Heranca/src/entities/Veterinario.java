package entities;

public class Veterinario {

	public static void examinar(Animal animal) {
		System.out.println(animal.emitirSom()); 
	}

}
