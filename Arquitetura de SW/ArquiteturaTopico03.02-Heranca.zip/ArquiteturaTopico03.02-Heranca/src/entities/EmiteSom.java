package entities;

public interface EmiteSom {
	
	public String emitirSom ();
	

}
