package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import entidade.Cliente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ClienteDAO {
	public static void cadastrarCliente(Cliente cliente) {

		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();

		String sqlInsert = "INSERT INTO cliente(nome, cpf, endereco, telefone) VALUES ( ?, ?, ?, ?)";

		PreparedStatement stm = null;

		try {
			stm = conn.prepareStatement(sqlInsert);
			stm.setString(1, cliente.getNome());
			stm.setString(2, cliente.getCpf());
			stm.setString(3, cliente.getEndereco());
			stm.setString(4, cliente.getTelefone());
			stm.execute();

		} catch (Exception e) {
			e.getMessage();
		}

	}

	public static void editarCliente(Cliente cliente) {

		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();

		String sqlUpdate = "update cliente set nome = ?, cpf = ? , endereco = ?, telefone = ? where id like ? ";

		PreparedStatement stm = null;

		try {
			stm = conn.prepareStatement(sqlUpdate);
			stm.setString(1, cliente.getNome());
			stm.setString(2, cliente.getCpf());
			stm.setString(3, cliente.getEndereco());
			stm.setString(4, cliente.getTelefone());
			stm.setInt(5, cliente.getId());
			stm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stm.close();

			} catch (SQLException e1) {
				e1.printStackTrace();

			}
		}

	}

	public static void apagarCliente(String pesquisa) {

		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();

		String sqlDelete = "delete from cliente where id = ?";

		PreparedStatement stm = null;

		try {
			stm = conn.prepareStatement(sqlDelete);
			stm.setString(1, pesquisa);
			stm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public static int pegarUltimoId() {
		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();
		List<Cliente> listaCliente = new ArrayList<>();

		String sqlSelect = "select * from cliente ";
		PreparedStatement stm = null;
		ResultSet rs = null;

		try {
			stm = conn.prepareStatement(sqlSelect);
			rs = stm.executeQuery();
			while (rs.next()) {
				listaCliente.add(
						new Cliente(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		List<Integer> ids = listaCliente.stream().map(x -> x.getId()).collect(Collectors.toList());

		return ids.get(ids.size() - 1) + 1;

	}

	public static List<Integer> mapearID() {
		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();
		List<Integer> listaID = new ArrayList<>();

		String sqlSelect = "select id from cliente ";
		PreparedStatement stm = null;
		ResultSet rs = null;

		try {
			stm = conn.prepareStatement(sqlSelect);
			rs = stm.executeQuery();
			while (rs.next()) {
				listaID.add(rs.getInt(1));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaID;

	}

	public static ObservableList<Cliente> converterArrayListToObservableList() {
		Conexao conexao = new Conexao();
		Connection conn = conexao.obtemConexao();
		List<Cliente> listaCliente = new ArrayList<>();

		String sqlSelect = "select * from cliente ";
		PreparedStatement stm = null;
		ResultSet rs = null;

		try {
			stm = conn.prepareStatement(sqlSelect);
			rs = stm.executeQuery();
			while (rs.next()) {
				listaCliente.add(
						new Cliente(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		ObservableList<Cliente> listaClienteObservable = FXCollections.observableArrayList();

		for (int i = 0; listaCliente.size() > i; i++) {

			listaClienteObservable.add(listaCliente.get(i));
		}

		return listaClienteObservable;
	}

}
