package controller;

import java.net.URL;
import java.util.ResourceBundle;

import entidade.Cliente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import services.ClienteService;

public class PesquisaClienteController implements Initializable {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TableColumn<Cliente, String> colunaId;

    @FXML
    private TextField txtPesquisa;

    @FXML
    private TableView<Cliente> tvCliente;

    @FXML
    private TableColumn<Cliente, String> colunaNome;

    @FXML
    private TableColumn<Cliente, String> colunaCpf;
    
    private static Cliente cliente;

	public static Cliente getCliente() {
		return cliente;
	}

	public static void setCliente(Cliente cliente) {
		PesquisaClienteController.cliente = cliente;
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// 0. Initialize the columns.
				colunaNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
				colunaCpf.setCellValueFactory(cellData -> cellData.getValue().cpfProperty());
				colunaId.setCellValueFactory(cellData -> cellData.getValue().idProperty());

				ObservableList<Cliente> masterData = FXCollections.observableArrayList();

				masterData = ClienteService.converterArrayListToObservableList();

				FilteredList<Cliente> filteredData = new FilteredList<>(masterData, p -> true);

				txtPesquisa.textProperty().addListener((observable, oldValue, newValue) -> {
					filteredData.setPredicate(cliente -> {

						// Checa se tem algo digitado, caso nao estiver digitado mostra todo mundo
						if (newValue == null || newValue.isEmpty()) {
							return true;
						}

						// Compara nome e login com todos os campos.
						String lowerCaseFilter = newValue.toLowerCase();

						if (cliente.getNome().toLowerCase().contains(lowerCaseFilter)) {
							return true; // Filter matches first name.
						} else if (cliente.getCpf().toLowerCase().contains(lowerCaseFilter)) {
							return true; // Filter matches last name.
						}
						return false; // Does not match.
					});
				});

				// 3. Wrap the FilteredList in a SortedList.

				SortedList<Cliente> sortedData = new SortedList<>(filteredData);

				// 4. Bind the SortedList comparator to the TableView comparator.
				sortedData.comparatorProperty().bind(tvCliente.comparatorProperty());

				// 5. Add sorted (and filtered) data to the table.
				tvCliente.setItems(sortedData);

				tvCliente.setOnMousePressed(new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
							PesquisaClienteController.setCliente(tvCliente.getSelectionModel().getSelectedItem());
							tvCliente.getScene().getWindow().hide();
						}
					}
				});
		
	}

}
