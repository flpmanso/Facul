package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import entidade.Cliente;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import persistence.ClienteDAO;
import services.ClienteService;
import services.MascarasFX;

public class ClienteController implements Initializable {

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtEndereco;

	@FXML
	private Button btnCadastrar;

	@FXML
	private TextField txtNome;

	@FXML
	private TextField txtTelefone;

	@FXML
	private TextField txtCpf;

	@FXML
	private Button btnDeletar;

	@FXML
	private Button btnPesquisar;

	@FXML
	private Button btnNovo;

	@FXML
	private Button btnEditar;

	@FXML
	void btnPesquisarOnAction(ActionEvent event) {
		try {
			Stage stage = new Stage();
			Parent root1 = FXMLLoader.load(getClass().getResource("/view/vwPesquisaCliente.fxml"));
			Scene scene = new Scene(root1);
			stage.setScene(scene);
			stage.show();

			stage.setOnHiding(new EventHandler<WindowEvent>() {

				@Override
				public void handle(WindowEvent event) {
					Platform.runLater(new Runnable() {

						@Override
						public void run() {
							if (PesquisaClienteController.getCliente() != null) {
								txtNome.setText(PesquisaClienteController.getCliente().getNome());
								txtCpf.setText(PesquisaClienteController.getCliente().getCpf());
								txtId.setText(Integer.toString(PesquisaClienteController.getCliente().getId()));
								txtEndereco.setText(PesquisaClienteController.getCliente().getEndereco());
								txtTelefone.setText(PesquisaClienteController.getCliente().getTelefone());
							}
						}
					});
				}
			});

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void btnNovoOnAction(ActionEvent event) {
		txtId.setText(Integer.toString(ClienteDAO.pegarUltimoId()));
		txtNome.clear();
		txtCpf.clear();
		txtEndereco.clear();
		txtTelefone.clear();

	}

	@FXML
	void btnCadastrarOnAction(ActionEvent event) {

		if ("".equals(txtNome.getText()) || "".equals(txtCpf.getText())) {

			Alert alert = new Alert(AlertType.INFORMATION, "Preencha os campos obrigatorios para cadastrar um Cliente",
					ButtonType.OK);
			alert.setTitle("Aten��o");
			alert.setHeaderText("Informa��o");
			alert.show();
		} else {

			if (ClienteService.isCPF(txtCpf.getText())) {

				Cliente cliente = new Cliente();

				cliente.setNome(txtNome.getText());
				cliente.setCpf(txtCpf.getText());
				cliente.setEndereco(txtEndereco.getText());
				cliente.setTelefone(txtTelefone.getText());

				ClienteService.cadastrarCliente(cliente);

				Alert alert = new Alert(AlertType.INFORMATION, "Cliente cadastrado com sucesso.", ButtonType.OK);
				alert.setTitle("Aten��o");
				alert.setHeaderText("Informa��o");
				alert.show();
			}

			else {
				Alert alert = new Alert(AlertType.INFORMATION, "CPF Invalido.", ButtonType.OK);
				alert.setTitle("Aten��o");
				alert.setHeaderText("Informa��o");
				alert.show();
			}

		}
	}

	@FXML
	void btnEditarOnAction(ActionEvent event) {
		if ("".equals(txtId.getText())) {
			Alert alert = new Alert(AlertType.INFORMATION, "Cliente nao informado para ser alterado", ButtonType.OK);
			alert.setTitle("Aten��o");
			alert.setHeaderText("Informa��o");
			alert.show();
		} else {

			if (ClienteService.mapearID().contains(Integer.parseInt(txtId.getText()))) {

				if ("".equals(txtNome.getText()) || "".equals(txtCpf.getText())) {

					Alert alert = new Alert(AlertType.INFORMATION, "Os campos obrigatorios nao podem ficar em branco.",
							ButtonType.OK);
					alert.setTitle("Aten��o");
					alert.setHeaderText("Informa��o");
					alert.show();
				} else {

					if (ClienteService.isCPF(txtCpf.getText())) {

						Cliente cliente = new Cliente();

						cliente.setId(Integer.parseInt(txtId.getText()));
						cliente.setNome(txtNome.getText());
						cliente.setCpf(txtCpf.getText());
						cliente.setEndereco(txtEndereco.getText());
						cliente.setTelefone(txtTelefone.getText());

						ClienteService.editarCliente(cliente);

						Alert alert = new Alert(AlertType.INFORMATION, "Cliente Alterado com Sucesso.", ButtonType.OK);
						alert.setTitle("Aten��o");
						alert.setHeaderText("Informa��o");
						alert.show();

						txtId.setText(Integer.toString(ClienteDAO.pegarUltimoId()));
						txtNome.clear();
						txtCpf.clear();
						txtEndereco.clear();
						txtTelefone.clear();
					}

					else {
						Alert alert = new Alert(AlertType.INFORMATION, "CPF Invalido.", ButtonType.OK);
						alert.setTitle("Aten��o");
						alert.setHeaderText("Informa��o");
						alert.show();
					}
				}
			} else {
				Alert alert = new Alert(AlertType.INFORMATION, "� necessario selecionar um cliente valido para alterar",
						ButtonType.OK);
				alert.setTitle("Aten��o");
				alert.setHeaderText("Informa��o");
				alert.show();
			}
		}
	}

	@FXML
	void btnDeletarOnAction(ActionEvent event) {
		if ("".equals(txtId.getText())) {
			Alert alert = new Alert(AlertType.INFORMATION, "Cliente nao informado para ser deletado", ButtonType.OK);
			alert.setTitle("Aten��o");
			alert.setHeaderText("Informa��o");
			alert.show();
		} else {

			if (ClienteService.mapearID().contains(Integer.parseInt(txtId.getText()))) {

				ClienteService.apagarCliente(txtId.getText());
				Alert alert = new Alert(AlertType.INFORMATION, "Cliente apagado com sucesso.", ButtonType.OK);
				alert.setTitle("Aten��o");
				alert.setHeaderText("Informa��o");
				alert.show();

				txtId.setText(Integer.toString(ClienteDAO.pegarUltimoId()));
				txtNome.clear();
				txtCpf.clear();
				txtEndereco.clear();
				txtTelefone.clear();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION, "� necessario selecionar um Cliente valido para deletar",
						ButtonType.OK);
				alert.setTitle("Aten��o");
				alert.setHeaderText("Informa��o");
				alert.show();
			}
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		MascarasFX.mascaraTelefone(txtTelefone);
		MascarasFX.mascaraCPF(txtCpf);
	}

}
