package bonificacao;

public enum Cargos {
	    NORMAL, COORDENADOR, DIRETOR, PRESIDENTE
}
